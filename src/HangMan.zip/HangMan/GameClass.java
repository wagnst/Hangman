package HangMan;
import java.util.Scanner;

public class GameClass {

    /* BUCHSTABE */
    private String eingabeBuchstabe = "";
    /* WORT */
    private String eingabeWort = "";
    /* FEHLVERSUCHE */
    private int AnzahlFehlVersuche = 0;
    /* MATCHED STRING */
    private StringBuilder matchString;
    /* HAS WON? */
    private boolean hasWon = false;

    public boolean isHasWon() {
        return this.hasWon;
    }

    private void setHasWon() {
        this.hasWon = true;
    }

    private String getEingabeBuchstabe() {
        return this.eingabeBuchstabe;
    }

    private void setEingabeBuchstabe(char eingabeBuchstabe) {
        this.eingabeBuchstabe += eingabeBuchstabe;
    }

    private String getEingabeWort() {
        return this.eingabeWort;
    }

    private void setEingabeWort(String eingabeWort) {
        this.eingabeWort = eingabeWort;
    }

    public int getAnzahlFehlVersuche() {
        return this.AnzahlFehlVersuche;
    }

    private void setAnzahlFehlVersuche() {
        this.AnzahlFehlVersuche += 1;
    }

    private void initMatchString() {
        matchString = new StringBuilder(this.eingabeWort.length());
        for(int i = 0; i < this.eingabeWort.length(); i++) {
            this.matchString.replace(i,i,"_");
        }
        //this.matchString.replace(0,this.eingabeWort.length(),"_");//ersetze alles mit Underscore
    }

    private StringBuilder getMatchString() {
        return this.matchString;
    }

    private void setMatchString(char buchStabe, int stelle) {
        // setze an Stelle stelle von MatchString buchStabe
        this.matchString.setCharAt(stelle, buchStabe);
    }

    /*
    zeichnet den Galgen, wobei n die Anzahl der Körperteile angibt, die bereits am Galgen hängen
     */
    private void zeichneGalgen(int n) {
        if(n == 0) {
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
        }
        else if(n == 1) {
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("O      |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
        }
        else if(n == 2) {
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("O      |");
            System.out.println("|      |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
            System.out.println("       |");
        }
        else if(n == 3) {
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("O      |");
            System.out.println("|      |");
            System.out.println("//       |");
            System.out.println("         |");
            System.out.println("       |");
            System.out.println("       |");
        }
        else if(n == 4) {
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("O      |");
            System.out.println("|      |");
            System.out.println("//       |");
            System.out.println("\\       |");
            System.out.println("       |");
            System.out.println("       |");
        }
        else if(n == 5) {
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("O      |");
            System.out.println("|      |");
            System.out.println("//       |");
            System.out.println("\\       |");
            System.out.println("//     |");
            System.out.println("       |");
        }
        else if(n == 6) {
            System.out.println("YOU LOST!");
            System.out.println("-------");
            System.out.println("|      |");
            System.out.println("O      |");
            System.out.println("|      |");
            System.out.println("//       |");
            System.out.println("\\       |");
            System.out.println("//     |");
            System.out.println("\\     |");
        }

        System.out.println("Match String: " + this.getMatchString().toString());
        System.out.println("Fehlversuche: " + this.getAnzahlFehlVersuche());
        System.out.println("Input String: " + this.getEingabeBuchstabe().toString());

    }

    /*
    ermöglicht es Spieler 1, das zu erratende Wort einzugeben. Nach der Eingabe soll das Wort
    durch 40 Leerzeilen aus der Konsole gescrollt werden, damit Spieler 2 es nicht sehen kann.
    Tipps:
        - Wandeln Sie das Wort vor der Rückgabe mit der Stringmethode toUpper() in Großbuchstaben
            um, damit Sie später nicht mehr zwischen Groß- und Kleinschreibung unterscheiden
            müssen.
        - Lesen Sie das Wort mit scanner.nextLine() ein, damit der Rest der Zeile nicht bei der
            Eingabe des ersten Buchstabens durch Spieler 2 verwertet wird.
    */
    public void wortEingeben(Scanner scanner) {
        String eingabeWort = "", eingabeText = "Bitte ein Wort eingeben: \n";

        System.out.println(eingabeText);

        if (scanner.hasNextLine()) {
            eingabeWort = scanner.nextLine();
            eingabeWort.split(" "); //löscht Leerzeichen
        }

        for(int i = 0; i < 40; i++){
            System.out.print("\n");
        }

        //Wort in Instanz setzen (Großbuchstaben)
        this.setEingabeWort(eingabeWort.toUpperCase());
        //Matchstring initialisieren und mit "_" füllen
        this.initMatchString();
    }

    /*
    ermöglicht es Spieler 2, einen zu erratenden Buchstaben einzugeben.
            Tipps:
            - Lesen Sie die nächste Zeile mit scanner.nextLine() von der Konsole ein.
            - Prüfen Sie die Länge des Strings auf genau einen Buchstaben.
            - Geben Sie den eingegebenen Buchstaben zurück, nachdem Sie zuvor den String mit der
    Stringfunktion toUpper() in Großbuchstaben umgewandelt haben.
    */
    public void buchstabenEingeben(Scanner scanner) {
        char eingabeBuchstabe= ' ';
        String eingabeText = "Bitte einen Buchstabe eingeben: \n";

        System.out.println(eingabeText);

        eingabeBuchstabe = Character.toUpperCase(scanner.next().charAt(0));

        this.setEingabeBuchstabe(eingabeBuchstabe);
        //prüfe zwischenstand
        this.zwischenstandBerechnen();
    }

    /*
    berechnet aus allen bisher bereits von Spieler 2 eingegebenen Buchstaben (Übergabe als String)
    und dem gesuchten Wort einen String, der
        - alle bereits erratenen Buchstaben darstellt
        - für alle noch nicht erratenen Buchstaben einen _ (Underscore) darstellt
    Beispiel:
        - Gesuchtes Wort: Hochschule
        - bereits eingegebene Buchstaben: estah
        - Rückgabe: H__hs_h__e
    */
    private void zwischenstandBerechnen() {
        boolean _BOOL = false;
        for(int i = 0; i < this.getEingabeBuchstabe().length(); i++) {
            _BOOL = false;
            for(int j = 0; j < this.getEingabeWort().length(); j++) {
                // wenn Buchstabe gleich, setze Matchstring
                if (this.eingabeWort.charAt(j) == this.eingabeBuchstabe.charAt(i)) {
                    this.setMatchString(this.eingabeWort.charAt(j), j);
                    _BOOL = true;
                }
            }
        }
        if (_BOOL == false) {
            this.setAnzahlFehlVersuche();
        }
        //check game status (fail tries, picture,...)
        spielstatusKalkulieren();
    }

    private void spielstatusKalkulieren() {
        if (this.getAnzahlFehlVersuche() <= 6) {
            zeichneGalgen(this.getAnzahlFehlVersuche());
        }
        if (this.matchString.toString().equals(this.getEingabeWort())) {
            this.setHasWon();
        }
    }

}
