package HangMan;
import java.util.Scanner;

public class HangMan {

    /*
    enthält das Hauptprogramm. Es öffnet zunächst die Konsole mit new Scanner(System.in), fordert
    dann den Spieler 1 zur Eingabe des gesuchten Wortes auf. Anschließend darf Spieler 2 solange
    neue Buchstaben eingeben, bis er entweder 7 Fehlversuche hinter sich hat oder das gesuchte
    Wort erraten hat.
     */
    public static void main(String ags[]) {
        //Scanner für Worteingabe
        Scanner wortScanner = new Scanner(System.in);

        // Spiel erzeugen
        GameClass SpielInstanz = new GameClass();

        // Spieler 1: Wort eingeben!
        SpielInstanz.wortEingeben(wortScanner);

        // Spiel beginnen (wenn versuche kleiner 7 or no winner)
        while(SpielInstanz.getAnzahlFehlVersuche() < 6 && !SpielInstanz.isHasWon()){
            SpielInstanz.buchstabenEingeben(wortScanner);
        }

        if(SpielInstanz.isHasWon()) {
            System.out.println("Game is over, you have WON with: " + SpielInstanz.getAnzahlFehlVersuche() + " fail tries!");
        } else {
            System.out.println("Game is over, you have LOST with: " + SpielInstanz.getAnzahlFehlVersuche() + " fail tries!");
        }

    }

}
